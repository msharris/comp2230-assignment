Place all .java files in the same directory and run "javac *.java" to compile our assignment.
In the same directory, run "java Assignment" to execute our assignment.

Our assignment makes use of lambda expressions in Java 8. Please compile and execute our assignment using Java 8.
